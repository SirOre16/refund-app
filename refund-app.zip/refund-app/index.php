<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

        <style>
            * {
                margin: 0;
                padding: 0;
                text-decoration: none;
            }

            body {
                font-family: Arial, sans-serif;
                box-sizing: border-box;
            }

            .chat-div {
                display: flex;
                flex-direction: column;
                position: fixed;
                top: 0;
                right: 0;
                left: 0;
                bottom: 0;
            }

            #preloader {
                border: 7px solid #f3f3f3;
                border-top: 7px solid #fe2c55;
                border-radius: 50%;
                width: 80px;
                height: 80px;
                position: fixed;
                left: 40%;
                top: 50%;
                z-index: 500;
                animation: spin 2s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }

            #chat-container {
                display: flex;
                flex-direction: column;
                padding: 10px;
                padding-bottom: 0;
                border-bottom: 1px solid #ccc;
                border-radius: 5px;
                overflow: hidden;
                overflow-y: scroll;
                background-color: #ffffff;
                flex: 1;
            }

            .date, .unread-message {
                background-color: #f0f0f0;
                max-width: 84%;
                height: 20px;
                padding: 6px;
                border-radius: 10px;
                background-color: #f5f6f7;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto;
                font-size: 0.8rem;
                color: #5c6c76;
                margin-bottom: 10px;
                font-weight: bold;
            }

            .message {
                display: flex;
                flex-direction: column;
                max-width: 84%;
                margin-bottom: 10px;
                padding-right: 10px;
                padding-top: 10px;
                padding-left: 10px;
                border-radius: 10px;
                border: 1px solid #ccc;
                position: relative;
            }

            .message.send {
                background-color: #e2f0ff;
                align-self: flex-end;
            }

            .message.reply {
                background-color: #f0f0f0;
                align-self: flex-start;
            }

            .message-text {
                white-space: pre-wrap;
                word-wrap: break-word;
            }

            .truncate-message-text {
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 25;
                overflow: hidden;
            }

            .time {
                font-size: 0.8rem;
                margin: 0;
                color: #999;
                align-self: flex-end;
                margin-top: 2px;
            }

            #user-input {
                padding: 10px;
                background-color: #fff;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .fa-camera {
                color: #4CAF50;
                margin: 5px;
                cursor: pointer;
                font-size: 20px;
            }

            .input-label {
                flex: 1;
                display: flex;
                border: 1px solid #ccc;
                border-radius: 5px;
                background: #f0f0f0;
            }

            #fileInput {
                display: none;
            }

            #message-input {
                flex: 1;
                height: 40px;
                outline: none;
                border: none;
                border-radius: 5px;
                background: #f0f0f0;
            }

            #message-input::placeholder {
                padding: 5px;
            }

            #send-button {
                font-size: 24px;
                color: #ffffff;
                margin-left: 10px;
                width: 45px;
                height: 45px;
                border-radius: 50%;
                background-color: #4CAF50;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                outline: none;
            }

            .menu-icon {
                align-self: flex-end;
                cursor: pointer;
                margin-top: -10px;
            }

            #three_dot {
                font-size: 30px;
                color: #999;
                margin-top: -10px;
            }

            #three_dot:hover {
                color: #fe2c55;
            }

            .message .send #three_dot {
                margin-right: -5px;
            }

            .message .reply #three_dot {
                margin-left: -5px;
            }

            .menu-alert {
                margin-top: 10px;
                background: #ffffff;
                border-radius: 3%;
                display: none;
                position: absolute;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
                padding: 10px;
                z-index: 999;
                min-width: 180px;
                max-width: 300px;
            }

            .triangle {
                width: 0;
                height: 0;
                border-left: 10px solid transparent;
                border-right: 10px solid transparent;
                border-bottom: 10px solid #f5f6f7;
                position: absolute;
                top: -10px;
            }

            .send .menu-alert {
                right: 0;
            }

            .send .triangle {
                right: 10px;
            }

            .reply .menu-alert {
                left: 0;
            }

            .reply .triangle {
                right: none;
                left: 10px;
            }

            .reply .menu-icon {
                align-self: flex-start;
            }

            .menu-alert-content {
                margin-bottom: 8px;
                font-size: 16px;
                color: #333;
                padding: 10px;
                border-radius: 8px;
                max-width: 260px;
            }

            .menu-alert-content p {
                margin: 8px 0;
            }

            .menu-alert-content hr {
                border: none;
                border-top: 1px solid #eee;
                margin: 6px 0;
            }

            .menu-alert-content i {
                margin-right: 10px;
                font-size: 18px;
                vertical-align: middle;
                color: #555;
            }

            .copied {
                color: green;
            }

            #delete-message, #delete-message i {
                color: #e74c3c;
                cursor: pointer;
            }

            #gallery {
                display: flex;
                overflow: auto;
                flex-wrap: nowrap;
            }

            .item {
                flex: 0 0 auto;
                position: relative;
                width: 150px;
                height: 150px;
                margin: 5px;
                background-color: #cccccc;
                border: 2px solid #cccccc; /* Border color */
                border-radius: 10px; /* Border radius */
            }

            .item img, .item video {
                width: 100%;
                height: 100%;
                object-fit: cover;
                border-radius: 10px; /* Border radius */
            }

            .delete-button {
                position: absolute;
                top: 0;
                right: 0;
                border: none;
                font-size: 16px;
                font-weight: bold;
                color: red;
                margin-left: 10px;
                width: 30px;
                height: 30px;
                border-radius: 50%;
                background: #f5f6f7;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                outline: none;
            }
        </style>

        <style>
            .media {
                display: flex;
                flex-direction: column;
                position: relative;
            }

            .send_media_gallery, .reply_media_gallery {
                position: relative;
                display: flex;
                margin-bottom: 10px;
            }

            .send_media_gallery {
                align-self: flex-end;
            }

            .reply_media_gallery {
                align-self: flex-start;
            }

            .media_gallery_time {
                color: #ffffff;
                position: absolute;
                right: 15px;
                bottom: 10px;
                pointer-events: none;
            }

            .media_item {
                display: flex;
                background: #ccc;
                justify-content: center;
                align-items: center;
                border-radius: 3%;
                border: 1px solid #ccc;
                overflow: hidden;
                cursor: pointer;
            }

            .media_item img, .media_item video {
                max-width: 280px;
                max-height: 300px;
                object-fit: cover;
                border-radius: 3%;
            }

            .message .media_item img, .message .media_item video {
                max-width: none;
                max-height: none;
            }

            .message .send_media_gallery, .message .reply_media_gallery {
                align-self: auto;
            }

            .message .media_item {
                flex: 1;
                flex-grow: 1;
                max-height: 350px;
            }

            .message .media_item img, .message .media_item video {
                flex: 1;
                flex-grow: 1;
                width: 100%;
                max-height: 100%;
            }

            @media screen and (min-width: 768px) {
                .message .media_item {
                    max-height: 400px;
                }
            }

            .play-button {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: #f1eee8;
                border-radius: 50%;
                width: 80px;
                height: 80px;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 25px;
                color: #000;
                pointer-events: none;
            }
        </style>

        <style>
            .body-dark-mode {
                background-color: #242526;
                color: #fff;
            }

            .dark-mode-chat-div #preloader {
                border: 7px solid #333333;
                border-top: 7px solid #4CAF50;
            }

            .dark-mode-chat-div #chat-container {
                border-bottom: 1px solid #444;
                background-color: #1e1e1e;
            }

            .dark-mode-chat-div .date, .dark-mode-chat-div .unread-message {
                background-color: #2e2e2e;
                color: #b0b0b0;
            }

            .dark-mode-chat-div .message {
                border: 1px solid #444;
            }

            .dark-mode-chat-div .message a {
                color: #5aa7ff;
            }

            .dark-mode-chat-div .message.send {
                background-color: #2a3b4d;
            }

            .dark-mode-chat-div .message.reply {
                background-color: #2e2e2e;
            }

            .dark-mode-chat-div .time {
                color: #888;
            }

            .dark-mode-chat-div #user-input {
                background-color: #1e1e1e;
            }

            .dark-mode-chat-div .input-label {
                background: #2e2e2e;
                border: 1px solid #444;
            }

            .dark-mode-chat-div #message-input {
                background: #2e2e2e;
                color: #fff;
            }

            .dark-mode-chat-div #send-button {
                background-color: #4CAF50;
                color: #ffffff;
            }

            .dark-mode-chat-div #three_dot {
                color: #888;
            }

            .dark-mode-chat-div .menu-alert {
                background: #2e2e2e;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
            }

            .dark-mode-chat-div .triangle {
                border-bottom: 10px solid #2e2e2e;
            }

            .dark-mode-chat-div .menu-alert-content {
                color: #e0e0e0;
                background: #2e2e2e;
            }

            .dark-mode-chat-div .menu-alert-content hr {
                border-top: 1px solid #555;
            }

            .dark-mode-chat-div .menu-alert-content i {
                color: #aaa;
            }

            .dark-mode-chat-div #delete-message, .dark-mode-chat-div #delete-message i {
                color: #e74c3c;
            }

            .dark-mode-chat-div .item {
                background-color: #333333;
                border: 2px solid #333333;
            }

            .dark-mode-chat-div .delete-button {
                background: #2e2e2e;
            }

            .dark-mode-chat-div .media_gallery_time {
                color: #e0e0e0;
            }

            .dark-mode-chat-div .media_item {
                background: #333333;
                border: 1px solid #444;
            }
        </style>

        <style>
            #mediaModal {
                display: none;
                flex-direction: column;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: #000000;
            }

            #cancelModal {
                color: red;
                font-size: 18px;
                position: fixed;
                top: 10px;
                left: 10px;
                width: 35px;
                height: 35px;
                border-radius: 50%;
                background-color: #f5f6f7;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                z-index: 900;
            }

            #modalContent {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100%;
            }

            #modalContent img, #modalContent video {
                max-width: 100%;
                max-height: 100%;
                object-fit: cover;
            }
        </style>

        <style>
            .speech-button {
                outline: none;
                position: absolute;
                top: 0;
                right: 10px;
                background: #f0f0f0;
                color: #4CAF50;
                border: none;
                font-size: 16px;
                font-weight: bold;
                cursor: pointer;
                padding: 5px;
            }

            .grecaptcha-badge {
                display: none !important;
            }

            .ai-action {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                margin: 12px 0;
                padding: 8px 4px;
                flex-wrap: wrap; /* Ensures responsiveness on smaller screens */
            }

            .ai-action a {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                padding: 10px 24px;
                font-weight: 600;
                font-size: 0.95rem;
                text-decoration: none;
                text-align: center;
                background: #4CAF50;
                color: #ffffff;
                color: #ffffff !important;
                border: 2px solid #4CAF50;
                border-radius: 50px;
                cursor: pointer;
                flex: 1 0 auto; /* Makes buttons equally sized if needed */
            }
        </style>

        <title>Chat</title>
    </head>

    <body>
        <div id="preloader"></div>

        <div id="mediaModal">
            <label id="cancelModal" onclick="closeModal();"><i class="fas fa-times"></i></label>
            <div id="modalContent"></div>
        </div>

        <div class="chat-div">
            <?php include_once "chat-header.php"; ?>
            <div id="chat-container">
                <?php // echo $messageHTML; ?>
            </div>
            <div id="gallery"></div>
            <div id="user-input">
                <label class="input-label">
                    <input type="file" name="upload[]" id="fileInput" accept="image/*,video/*" onclick="checkIfLoggedIn(event);">
                    <i class="fas fa-camera" title="Upload file"></i>
                    <textarea id="message-input" autocorrect="on" placeholder="Type your message..."></textarea>
                </label>
                <div id="send-button" title="Send">
                    <i class="fas fa-paper-plane send-button"></i>
                </div>
            </div>
        </div>

        <script>
            let preloader = document.getElementById("preloader");
            preloader.style.display = "none";

            const messageInput = document.getElementById('message-input');
            const sendButton = document.getElementById('send-button');
            const chatContainer = document.getElementById('chat-container');
            let unreadMessage = document.querySelector(".unread-message");

            // Speech functionality
            const play = '<i class="fas fa-volume-up"></i>';
            const pause = '<i class="fas fa-pause"></i>';

            function doneSpeaking() {
                const speechButtons = document.getElementsByClassName("speech-button");
                for (let i = 0; i < speechButtons.length; i++) {
                    speechButtons[i].innerHTML = play;
                }
            }

            function toggleTextToSpeech(button, messageText) {
                if (button.innerHTML === play) {
                    doneSpeaking();
                    button.innerHTML = pause;

                    // Check if Android interface is available
                    if (typeof Android !== 'undefined' && Android.startSpeaking) {
                        Android.startSpeaking(messageText);
                    } else {
                        // Fallback for web: use Web Speech API
                        if ('speechSynthesis' in window) {
                            const utterance = new SpeechSynthesisUtterance(messageText);
                            window.speechSynthesis.speak(utterance);
                        }
                    }
                } else {
                    button.innerHTML = play;

                    // Check if Android interface is available
                    if (typeof Android !== 'undefined' && Android.stopSpeaking) {
                        Android.stopSpeaking();
                    } else {
                        // Fallback for web
                        if ('speechSynthesis' in window) {
                            window.speechSynthesis.cancel();
                        }
                    }
                }
            }

            // Function to initialize speech buttons for AI responses
            function initSpeechButtons() {
                const speechButtons = document.getElementsByClassName("speech-button");
                for (let i = 0; i < speechButtons.length; i++) {
                    const button = speechButtons[i];

                    // Remove existing event listeners by cloning
                    const newButton = button.cloneNode(true);
                    button.parentNode.replaceChild(newButton, button);

                    newButton.addEventListener('click', function(e) {
                        e.stopPropagation();
                        const messageElement = this.closest('.message');
                        const messageTextElement = messageElement.querySelector('.message-text');
                        let messageText = '';
                        if (messageTextElement) {
                            messageText = messageTextElement.innerText || messageTextElement.textContent;
                        }
                        toggleTextToSpeech(this, messageText);
                    });
                }
            }

            if (unreadMessage) {
                const scrollPosition = unreadMessage.offsetTop - chatContainer.offsetTop;
                chatContainer.scrollTop = scrollPosition;
            } else {
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }

            function adjustTextareaHeight() {
                const minHeight = 40;
                const maxHeight = 120;
                messageInput.style.height = 'auto'; // Reset height to get accurate scrollHeight
                const newHeight = Math.min(Math.max(messageInput.scrollHeight, minHeight), maxHeight);
                messageInput.style.height = newHeight + 'px';
            }

            messageInput.addEventListener('input', adjustTextareaHeight);

            function checkForTruncatedText() {
                const messageTextElements = document.querySelectorAll('.truncate-message-text');

                // Check if the text is truncated (exceeds the number of lines)
                for (let i = 0; i < messageTextElements.length; i++) {
                    const element = messageTextElements[i];
                    const isTruncated = element.scrollHeight > element.clientHeight;

                    if (isTruncated) {
                        element.style.cursor = "pointer";
                        element.addEventListener('click', function() {
                            element.scrollIntoView({ behavior: "smooth" });
                        });
                    }
                }
            }
            checkForTruncatedText();

            async function handleUserMessage() {

                // Get reCAPTCHA token

                // remove recaptcha if you want or call it once you can use cookie to check if not called yet
                let token = '';
                /* try {
                    token = await grecaptcha.enterprise.execute('6Lf7TFgtAAAAAFOpmb6VUMzMv07dtw5N5BFN0Nrh', {action: 'AI'});
                } catch (error) {
                    console.error('reCAPTCHA error:', error);
                }*/

                // force user to login
                /* if(!checkIfLoggedIn(event)){
                    return;
                } */

                const userMessage = messageInput.value.trim();

                if (userMessage !== "" || file) {
                    displayMessage(userMessage, file);
                    checkForTruncatedText();
                    generateThumbnails();
                    messageInput.value = "";
                    messageInput.style.height = '40px';
                    sendMessage(userMessage, file, token);
                    // Reset the file input
                    fileInput.value = null;
                    file = null;
                    gallery.innerHTML = "";
                }
            }

            function displayMessage(message, file) {
                message = htmlspecialchars(message);
                message = findLink(message);
                var time = getCurrentTime();

                let messageHTML = '';
                let mediaHTML = '';
                let textHTML = '';

                // Build media block if a file exists
                if (file) {
                    if (file.type.includes("image")) {
                        mediaHTML += `
                        <div class="send_media_gallery" onclick="showMediaItems(event)">
                            <div class="media_item">
                                <img src="${URL.createObjectURL(file)}" />
                            </div>
                        </div>`;
                    } else if (file.type.includes("video")) {
                        mediaHTML += `
                        <div class="send_media_gallery" onclick="showMediaItems(event)">
                            <div class="media_item">
                                <video src="${URL.createObjectURL(file)}" class="upload_video" controlsList="nodownload"></video>
                                <div class="play-button" id="playButton">
                                    <i class="fas fa-play"></i>
                                </div>
                            </div>
                        </div>`;
                    }
                }

                // Build text block if there's a message (and it's not a pure-media message)
                if (message.trim() !== "") {
                    textHTML += `<label class="message-text truncate-message-text" onclick="toggleTextTruncation(this)">${message}</label>`;
                }

                // If nothing to show, bail out
                if (mediaHTML === '' && textHTML === '') return;

                // Single wrapper for all cases
                messageHTML += `
                <div class="message send">
                    <div class="menu-icon" onclick="showMenuAlert(event);">
                        <div id="three_dot">...</div>
                        <div class="menu-alert">
                            <div class="triangle"></div>
                            <div class="menu-alert-content" message_id="" role="send">
                                <p><i class="fas fa-share"></i> Share</p>
                                <hr />
                                <p onclick="copyMessage(event);"><i class="fas fa-copy"></i> Copy</p>
                                <hr />
                            </div>
                        </div>
                    </div>
                    ${mediaHTML}
                    ${textHTML}
                    <label class="time">${time}</label>
                </div>`;

                chatContainer.innerHTML += messageHTML;
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }

            sendButton.addEventListener('click', handleUserMessage);

            // Add this at the beginning of your script section - initialize conversation history
            let conversationHistory = [];

            // Modify the sendMessage function to include reCAPTCHA token
            function sendMessage(message, file, token) {
                const formData = new FormData();
                formData.append('message', message);
                formData.append('recaptcha_token', token);

                // Add conversation history to the request
                formData.append('conversation_history', JSON.stringify(conversationHistory));

                if (file) {
                    formData.append('messageFile', file);
                }

                const xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                    preloader.style.display = "block";

                    if (xhr.readyState === 4) {
                        preloader.style.display = "none";
                        if (xhr.status === 200) {
                            const result = xhr.responseText;

                            // Store the user message in conversation history
                            conversationHistory.push({
                                role: 'user',
                                content: message
                            });

                            // Store the AI response in conversation history
                            // We need to extract just the text from the HTML response
                            const tempDiv = document.createElement('div');
                            tempDiv.innerHTML = result;
                            const messageText = tempDiv.querySelector('.message-text');
                            if (messageText) {
                                conversationHistory.push({
                                    role: 'assistant',
                                    content: messageText.innerText || messageText.textContent
                                });
                            }

                            const lastMenuAlert = document.querySelectorAll(`[message_id]:last-child`);
                            if (lastMenuAlert.length > 0) {
                                lastMenuAlert[lastMenuAlert.length - 1].setAttribute("message_id", result);
                            }

                            const lastMessage = document.querySelector('.message:last-child');
                            const lastMedia = document.querySelector('.media:last-child');

                            if (lastMessage) {
                                lastMessage.setAttribute("message_id", result);
                            }

                            if (lastMedia) {
                                lastMedia.setAttribute("message_id", result);
                            }

                            // Pass the AI response to receiveReply
                            receiveReply(result);
                        } else {
                            console.error("Error sending message. Status:", xhr.status);
                        }
                    }
                };

                xhr.open("POST", "ai-handler.php", true);
                xhr.send(formData);
            }

            function receiveReply(aiResponse) {
                if (aiResponse !== "" && aiResponse !== undefined) {
                    chatContainer.innerHTML += aiResponse;
                    generateThumbnails();
                    chatContainer.scrollTop = chatContainer.scrollHeight;

                    // Initialize speech buttons for the new AI response
                    initSpeechButtons();
                    doneSpeaking();

                    // Automatically start speaking the new AI response
                    const speechButtons = document.getElementsByClassName("speech-button");
                    if (speechButtons.length > 0) {
                        // Get the last speech button (the one for the new message)
                        const lastSpeechButton = speechButtons[speechButtons.length - 1];
                        // Trigger click to start speaking
                        lastSpeechButton.click();
                    }
                }
            }
        </script>

        <script>
            const fileInput = document.getElementById("fileInput");
            const gallery = document.getElementById("gallery");
            let file;

            fileInput.addEventListener("change", function () {
                file = fileInput.files[0]; // Get the first file

                // Check file size (5MB = 5 * 1024 * 1024 bytes)
                if (file && file.size > 5 * 1024 * 1024) {
                    alert("File must not be more than 5MB");
                    fileInput.value = null; // Reset the file input
                    file = null;
                    gallery.innerHTML = ""; // Clear the gallery
                    return;
                }

                let galleryContent = '';

                if (file) {
                    let itemHTML = '<div class="item">';

                    if (file.type.includes("image")) {
                        itemHTML += `<img src="${URL.createObjectURL(file)}" class="upload_img" />`;
                    } else if (file.type.includes("video")) {
                        itemHTML += `<video src="${URL.createObjectURL(file)}" class="upload_video" controls controlsList="nodownload"></video>`;
                    } else {
                        fileInput.value = null; // Reset the file input
                        file = null;
                        return;
                    }

                    itemHTML += '<button class="delete-button" onclick="deleteItem(this)">X</button>';
                    itemHTML += '</div>';

                    galleryContent += itemHTML;
                }

                gallery.innerHTML = galleryContent;
            });

            function deleteItem(button) {
                const item = button.parentElement;
                gallery.removeChild(item);
                fileInput.value = null; // Reset the file input
                file = null;
            }
        </script>

        <script>
            // Show the menu alert
            function showMenuAlert(event) {
                var clickedMenuIcon = event.target.closest('.menu-icon');
                var menuAlert = clickedMenuIcon.querySelector('.menu-alert');

                // Display the menu alert
                menuAlert.style.display = "block";

                // Function to close the menu alert on window click
                function closeMenuAlertOnClick(event) {
                    if (!clickedMenuIcon.contains(event.target)) {
                        menuAlert.style.display = "none";
                        window.removeEventListener('click', closeMenuAlertOnClick); // Remove the event listener after closing the alert
                    }
                }

                // Add event listener for window click to close the menu alert
                window.addEventListener('click', closeMenuAlertOnClick);
            }

            // Function to copy menu message to clipboard
            function copyMessage(event) {
                var copyButton = event.target;
                copyButton.innerHTML = `✓ Copied!`;
                copyButton.classList.add('copied');

                // Reset copy button text and color after 2 seconds
                setTimeout(function() {
                    copyButton.innerHTML = `<i class="fas fa-copy"></i> Copy`;
                    copyButton.classList.remove('copied');
                }, 2000);

                // Copy message to clipboard
                const message = event.target.closest('.message');
                const textToCopy = message.querySelector('.message-text').innerText;
                const tempTextArea = document.createElement('textarea');
                tempTextArea.value = textToCopy;
                document.body.appendChild(tempTextArea);
                tempTextArea.select();
                document.execCommand('copy');
                document.body.removeChild(tempTextArea);
                console.log('Text copied to clipboard: ' + textToCopy);
            }

            function deleteMessage(event) {
                const parentMessageID = event.target.parentElement;
                const messageID = parentMessageID.getAttribute("message_id");
                const role = parentMessageID.getAttribute("role");
                showDeleteMessageAlert(messageID, role);
            }
        </script>

        <script>
            function findLink(post) {
                // Updated regular expression pattern to match URLs without http:// or https://
                const patternURLs = /(?<!\S)(?:(www\.)?([^\s]+\.\w{2,}(?:\/[^\s]*)?))(?!\S)/;

                // Callback function to replace URLs with anchor tags
                const replaceURLs = function (match, www, url) {
                    let httpUrl = url;
                    if (!/^https?:\/\//.test(url)) {
                        httpUrl = 'http://' + url; // Add http:// to URLs without protocol
                    }
                    return '<a href="' + httpUrl + '" target="_blank">' + (www ? www + '.' : '') + url + '</a>';
                };

                // Replace URLs with anchor tags using the callback function
                let postWithLinks = post.replace(patternURLs, replaceURLs);

                // Regular expression pattern to match hashtags
                const patternHashtags = /#(\w*[a-zA-Z_]\w*)/;

                // Replace hashtags with anchor tags
                postWithLinks = postWithLinks.replace(patternHashtags, '<a href="search.php?hashtag=#$1" target="_blank">#$1</a>');

                return postWithLinks;
            }

            function htmlspecialchars(data) {
                const div = document.createElement('div');
                div.textContent = data;
                return div.innerHTML;
            }

            function getCurrentTime() {
                // Get the current date and time
                var currentDate = new Date();

                // Get the hours in 12-hour format
                var hours = currentDate.getHours();
                if (hours > 12) {
                    hours = hours - 12;
                } else if (hours === 0) {
                    hours = 12;
                }

                // Get the minutes with leading zero if necessary
                var minutes = currentDate.getMinutes();
                if (minutes < 10) {
                    minutes = '0' + minutes;
                }

                // Get AM/PM
                var ampm = 'am';
                if (currentDate.getHours() >= 12) {
                    ampm = 'pm';
                }

                // Concatenate the formatted time
                var formattedTime = hours + ':' + minutes + ampm;

                // Return the result
                return formattedTime;
            }
        </script>

        <script>
            function toggleTextTruncation(event) {
                // Check if the clicked post-content is truncated or not
                if (!event.classList.contains("truncate-message-text")) {
                    event.classList.add("truncate-message-text");
                } else {
                    event.classList.remove("truncate-message-text");
                }
            }
        </script>

        <script type="text/javascript" charset="utf-8">
            let closeModalCalled = false;

            // Function to open the modal and display media content
            function showMediaItems(event) {
                const modalMedia = document.getElementById('mediaModal');
                var modalContent = document.getElementById('modalContent');
                modalContent.innerHTML = '';  // Clear any previous content

                const tempElement = document.createElement('div');
                tempElement.innerHTML = event.target.outerHTML;
                const mediaElement = tempElement.firstElementChild;

                if (mediaElement.tagName === "IMG") {
                    modalContent.innerHTML = event.target.outerHTML;
                } else if (mediaElement.tagName === 'VIDEO') {
                    modalContent.innerHTML = `<video src="${mediaElement.src}" class="upload_video" autoplay controls controlsList="nodownload"></video>`;
                    const videoElement = modalContent.querySelector('video');
                    // Play the video
                    videoElement.play();
                }

                modalMedia.style.display = 'flex';
                closeModalCalled = false;
                history.pushState(null, null, location.href);
                window.addEventListener('popstate', disableBackButtonOnce);
            }

            // Function to close the modal
            function closeModal() {
                var modalContent = document.getElementById('modalContent');
                const galleryModal = document.getElementById('mediaModal');
                galleryModal.style.display = 'none';
                modalContent.innerHTML = '';  // Clear any previous content
                closeModalCalled = true;
            }

            function disableBackButtonOnce() {
                if (!closeModalCalled) {
                    closeModal();
                    window.removeEventListener('popstate', disableBackButtonOnce);
                } else {
                    history.back();
                }
            }
        </script>

        <script>
            function generateThumbnails() {
                var videoElements = document.querySelectorAll("video");

                for (let i = 0; i < videoElements.length; i++) {
                    const video = videoElements[i];

                    // Skip if the video already has a poster attribute
                    if (video.getAttribute('poster')) {
                        continue;
                    }

                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');

                    video.addEventListener('loadeddata', function() {
                        video.currentTime = 1; // Capture the thumbnail at the 1-second mark
                    });

                    video.addEventListener('seeked', function() {
                        // Set canvas dimensions to video dimensions
                        canvas.width = video.videoWidth;
                        canvas.height = video.videoHeight;
                        // Draw the current frame of the video onto the canvas
                        ctx.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
                        // Convert the canvas to a data URL and set it as the poster attribute of the video
                        const dataURL = canvas.toDataURL('image/png');
                        video.setAttribute('poster', dataURL);
                    });

                    // Load the video to trigger the 'loadeddata' event
                    video.load();
                }
            }

            document.addEventListener('DOMContentLoaded', function() {
                generateThumbnails();
                // Initialize speech buttons for existing AI responses
                initSpeechButtons();
            });
        </script>
    </body>
</html>