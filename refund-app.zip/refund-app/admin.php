<?php

/** @var mysqli $conn */

require_once "db.php";


// =========================================
// GET ORDERS
// =========================================

$stmt = mysqli_prepare($conn, "
    SELECT
        orders.id,
        customers.name,
        customers.email,
        orders.product_name,
        orders.amount,
        orders.order_date,
        orders.is_final_sale,
        orders.item_status
    FROM orders
    INNER JOIN customers
        ON orders.customer_id = customers.id
    ORDER BY orders.id DESC
");

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


// =========================================
// REFUND DECISION
// =========================================

function getRefundDecision($order)
{
    // Final sale
    if ($order['is_final_sale'] == 1) {

        return [
            'decision' => 'DENIED',
            'reason' => 'Final sale items are not eligible for refunds.'
        ];
    }


    // Refund period = 30 days
    $orderDate = new DateTime($order['order_date']);
    $today = new DateTime();

    $daysOld = $orderDate->diff($today)->days;


    if ($daysOld > 30) {

        return [
            'decision' => 'DENIED',
            'reason' => 'The order is older than the 30-day refund period.'
        ];
    }


    // Refunds above $500 require human review
    if ($order['amount'] > 500) {

        return [
            'decision' => 'ESCALATED',
            'reason' => 'Refunds above $500 require human review.'
        ];
    }


    // Damaged item
    if ($order['item_status'] === 'damaged') {

        return [
            'decision' => 'APPROVED',
            'reason' => 'The item was reported as damaged and is eligible for a refund.'
        ];
    }


    // Incorrect item
    if ($order['item_status'] === 'incorrect') {

        return [
            'decision' => 'APPROVED',
            'reason' => 'The customer received an incorrect item and may qualify for a refund.'
        ];
    }


    // No qualifying issue
    return [
        'decision' => 'ESCALATED',
        'reason' => 'The request requires additional review because no qualifying issue was identified.'
    ];
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Refund Support Dashboard</title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f7f8fa;
            color: #1f2937;
        }


        /* =========================================
           HEADER
        ========================================= */

        .header {
            background: #ffffff;
            border-bottom: 1px solid #e5e7eb;
            padding: 22px 32px;
        }


        .header-inner {
            max-width: 1400px;
            margin: 0 auto;
        }


        .header h1 {
            margin: 0;
            font-size: 23px;
            font-weight: 700;
            color: #111827;
            letter-spacing: -0.3px;
        }


        .header p {
            margin: 7px 0 0;
            color: #6b7280;
            font-size: 14px;
        }


        /* =========================================
           MAIN CONTAINER
        ========================================= */

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 32px;
        }


        /* =========================================
           SUMMARY CARDS
        ========================================= */

        .summary {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }


        .card {
            position: relative;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            padding: 22px;
            min-height: 125px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.03);
            overflow: hidden;
        }


        .card::after {
            content: "";
            position: absolute;
            right: -25px;
            bottom: -35px;
            width: 90px;
            height: 90px;
            border-radius: 50%;
            background: #f3f4f6;
        }


        .card h3 {
            margin: 0 0 12px;
            font-size: 13px;
            font-weight: 600;
            color: #6b7280;
        }


        .card strong {
            display: block;
            font-size: 30px;
            line-height: 1;
            color: #111827;
        }


        .card.total {
            border-left: 4px solid #374151;
        }


        .card.approved {
            border-left: 4px solid #16a34a;
        }


        .card.denied {
            border-left: 4px solid #dc2626;
        }


        .card.escalated {
            border-left: 4px solid #d97706;
        }


        .card.approved strong {
            color: #15803d;
        }


        .card.denied strong {
            color: #dc2626;
        }


        .card.escalated strong {
            color: #b45309;
        }


        /* =========================================
           TABLE SECTION
        ========================================= */

        .table-section {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
            overflow: hidden;
        }


        .table-header {
            padding: 20px 22px;
            border-bottom: 1px solid #e5e7eb;
        }


        .table-header h2 {
            margin: 0;
            font-size: 17px;
            color: #111827;
        }


        .table-header p {
            margin: 5px 0 0;
            font-size: 13px;
            color: #6b7280;
        }


        .table-box {
            overflow-x: auto;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }


        th,
        td {
            padding: 16px 18px;
            text-align: left;
            border-bottom: 1px solid #f0f1f3;
            vertical-align: middle;
        }


        th {
            background: #fafafa;
            font-size: 11px;
            font-weight: 700;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }


        td {
            font-size: 13px;
            color: #374151;
        }


        tbody tr {
            transition: background 0.15s ease;
        }


        tbody tr:hover {
            background: #fafbfc;
        }


        tbody tr:last-child td {
            border-bottom: none;
        }


        /* =========================================
           LIST NUMBER
        ========================================= */

        .number {
            color: #9ca3af;
            font-size: 12px;
            font-weight: 600;
        }


        /* =========================================
           DATABASE ID
        ========================================= */

        .order-id {
            color: #6b7280;
            font-size: 12px;
            font-weight: 600;
        }


        /* =========================================
           CUSTOMER
        ========================================= */

        .customer-name {
            display: block;
            color: #111827;
            font-weight: 600;
            margin-bottom: 4px;
        }


        .customer-email {
            display: block;
            color: #9ca3af;
            font-size: 11px;
        }


        /* =========================================
           PRODUCT
        ========================================= */

        .product-name {
            color: #374151;
            font-weight: 500;
        }


        /* =========================================
           AMOUNT
        ========================================= */

        .amount {
            color: #111827;
            font-weight: 700;
            white-space: nowrap;
        }


        /* =========================================
           DATE
        ========================================= */

        .date {
            color: #6b7280;
            white-space: nowrap;
        }


        /* =========================================
           ITEM STATUS
        ========================================= */

        .item-status {
            display: inline-flex;
            align-items: center;
            padding: 5px 9px;
            border-radius: 6px;
            background: #f3f4f6;
            color: #4b5563;
            font-size: 11px;
            font-weight: 600;
        }


        /* =========================================
           DECISION
        ========================================= */

        .decision {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 7px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.2px;
        }


        .decision::before {
            content: "";
            width: 6px;
            height: 6px;
            border-radius: 50%;
        }


        .decision.approved {
            background: #ecfdf3;
            color: #15803d;
        }


        .decision.approved::before {
            background: #16a34a;
        }


        .decision.denied {
            background: #fef2f2;
            color: #dc2626;
        }


        .decision.denied::before {
            background: #dc2626;
        }


        .decision.escalated {
            background: #fff7ed;
            color: #c2410c;
        }


        .decision.escalated::before {
            background: #f97316;
        }


        /* =========================================
           AUDIT NOTE
        ========================================= */

        .reason {
            color: #6b7280;
            max-width: 320px;
            line-height: 1.5;
            font-size: 12px;
        }


        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 900px) {

            .summary {
                grid-template-columns: repeat(2, 1fr);
            }

        }


        @media (max-width: 700px) {

            .header {
                padding: 20px;
            }


            .header h1 {
                font-size: 19px;
            }


            .container {
                padding: 20px 12px;
            }


            .summary {
                grid-template-columns: 1fr 1fr;
                gap: 12px;
            }


            .card {
                min-height: 110px;
                padding: 17px;
            }


            .card strong {
                font-size: 25px;
            }


            .table-header {
                padding: 18px;
            }

        }


        @media (max-width: 450px) {

            .summary {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>


<body>


<!-- =========================================
     HEADER
========================================= -->

<div class="header">

    <div class="header-inner">

        <h1>AI-Powered Customer Support Refund System</h1>

        <p>Support Dashboard</p>

    </div>

</div>


<div class="container">


    <!-- =========================================
         SUMMARY
    ========================================= -->

    <div class="summary">


        <!-- TOTAL -->

        <div class="card total">

            <h3>Total Requests</h3>

            <strong>

                <?php echo mysqli_num_rows($result); ?>

            </strong>

        </div>


        <?php

        mysqli_data_seek($result, 0);

        $approved = 0;
        $denied = 0;
        $escalated = 0;


        while ($order = mysqli_fetch_assoc($result)) {

            $refund = getRefundDecision($order);


            if ($refund['decision'] === 'APPROVED') {
                $approved++;
            }


            if ($refund['decision'] === 'DENIED') {
                $denied++;
            }


            if ($refund['decision'] === 'ESCALATED') {
                $escalated++;
            }

        }


        mysqli_data_seek($result, 0);

        ?>


        <!-- APPROVED -->

        <div class="card approved">

            <h3>Approved</h3>

            <strong>

                <?php echo $approved; ?>

            </strong>

        </div>


        <!-- DENIED -->

        <div class="card denied">

            <h3>Denied</h3>

            <strong>

                <?php echo $denied; ?>

            </strong>

        </div>


        <!-- ESCALATED -->

        <div class="card escalated">

            <h3>Escalated</h3>

            <strong>

                <?php echo $escalated; ?>

            </strong>

        </div>


    </div>


    <!-- =========================================
         REFUND REQUESTS
    ========================================= -->

    <div class="table-section">


        <div class="table-header">

            <h2>Refund Requests</h2>

            <p>Review customer refund decisions and AI audit notes.</p>

        </div>


        <div class="table-box">

            <table>

                <thead>

                    <tr>

                        <th>#</th>

                        <th>ID</th>

                        <th>Customer</th>

                        <th>Product</th>

                        <th>Amount</th>

                        <th>Order Date</th>

                        <th>Item Status</th>

                        <th>Decision</th>

                        <th>Audit Note</th>

                    </tr>

                </thead>


                <tbody>


                    <?php

                    $number = 1;

                    while ($order = mysqli_fetch_assoc($result)):

                    ?>


                        <?php

                        $refund = getRefundDecision($order);

                        $decision = $refund['decision'];

                        $class = strtolower($decision);

                        ?>


                        <tr>


                            <!-- LIST NUMBER -->

                            <td>

                                <span class="number">

                                    <?php echo $number++; ?>

                                </span>

                            </td>


                            <!-- DATABASE ID -->

                            <td>

                                <span class="order-id">

                                    <?php echo $order['id']; ?>

                                </span>

                            </td>


                            <!-- CUSTOMER -->

                            <td>

                                <span class="customer-name">

                                    <?php

                                    echo htmlspecialchars($order['name']);

                                    ?>

                                </span>


                                <span class="customer-email">

                                    <?php

                                    echo htmlspecialchars($order['email']);

                                    ?>

                                </span>

                            </td>


                            <!-- PRODUCT -->

                            <td>

                                <span class="product-name">

                                    <?php

                                    echo htmlspecialchars($order['product_name']);

                                    ?>

                                </span>

                            </td>


                            <!-- AMOUNT -->

                            <td>

                                <span class="amount">

                                    $<?php

                                    echo number_format($order['amount'], 2);

                                    ?>

                                </span>

                            </td>


                            <!-- ORDER DATE -->

                            <td>

                                <span class="date">

                                    <?php

                                    echo htmlspecialchars($order['order_date']);

                                    ?>

                                </span>

                            </td>


                            <!-- ITEM STATUS -->

                            <td>

                                <span class="item-status">

                                    <?php

                                    echo htmlspecialchars(
                                        ucfirst($order['item_status'])
                                    );

                                    ?>

                                </span>

                            </td>


                            <!-- DECISION -->

                            <td>

                                <span class="decision <?php echo $class; ?>">

                                    <?php echo $decision; ?>

                                </span>

                            </td>


                            <!-- AUDIT NOTE -->

                            <td>

                                <div class="reason">

                                    <?php

                                    echo htmlspecialchars($refund['reason']);

                                    ?>

                                </div>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                </tbody>

            </table>

        </div>

    </div>


</div>


</body>

</html>