CREATE DATABASE IF NOT EXISTS refund_app;

USE refund_app;


-- =========================================
-- CUSTOMERS TABLE
-- =========================================

CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE
);


-- =========================================
-- ORDERS TABLE
-- =========================================

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    order_date DATE NOT NULL,
    is_final_sale TINYINT(1) NOT NULL DEFAULT 0,
    item_status ENUM('normal', 'damaged', 'incorrect') NOT NULL DEFAULT 'normal',

    FOREIGN KEY (customer_id)
        REFERENCES customers(id)
        ON DELETE CASCADE
);


-- =========================================
-- 15 CUSTOMERS
-- =========================================

INSERT INTO customers (name, email) VALUES
('John Carter', 'john.carter@modafvibe.com'),
('Sarah Williams', 'sarah.williams@modafvibe.com'),
('Michael Brown', 'michael.brown@modafvibe.com'),
('Emily Davis', 'emily.davis@modafvibe.com'),
('Daniel Wilson', 'daniel.wilson@modafvibe.com'),
('Olivia Moore', 'olivia.moore@modafvibe.com'),
('James Taylor', 'james.taylor@modafvibe.com'),
('Sophia Anderson', 'sophia.anderson@modafvibe.com'),
('William Thomas', 'william.thomas@modafvibe.com'),
('Ava Jackson', 'ava.jackson@modafvibe.com'),
('Benjamin White', 'benjamin.white@modafvibe.com'),
('Mia Harris', 'mia.harris@modafvibe.com'),
('Lucas Martin', 'lucas.martin@modafvibe.com'),
('Charlotte Thompson', 'charlotte.thompson@modafvibe.com'),
('Henry Garcia', 'henry.garcia@modafvibe.com');


-- =========================================
-- ORDERS
-- =========================================

INSERT INTO orders
(customer_id, product_name, amount, order_date, is_final_sale, item_status)
VALUES

-- 1. Normal refundable order
(1, 'Wireless Headphones', 120.00, '2026-09-20', 0, 'normal'),

-- 2. Final sale item
(2, 'Designer Shoes', 180.00, '2026-09-22', 1, 'normal'),

-- 3. Old order
(3, 'Smart Watch', 250.00, '2026-07-01', 0, 'normal'),

-- 4. Above $500 - requires human review
(4, 'Laptop Computer', 850.00, '2026-09-23', 0, 'normal'),

-- 5. Damaged item
(5, 'Bluetooth Speaker', 95.00, '2026-09-24', 0, 'damaged'),

-- 6. Incorrect item
(6, 'Running Shoes', 140.00, '2026-09-24', 0, 'incorrect'),

-- 7. Normal refundable order
(7, 'Mechanical Keyboard', 110.00, '2026-09-21', 0, 'normal'),

-- 8. Final sale + damaged
(8, 'Clearance Jacket', 75.00, '2026-09-23', 1, 'damaged'),

-- 9. Expensive damaged item - human review
(9, '4K Television', 720.00, '2026-09-25', 0, 'damaged'),

-- 10. Normal order
(10, 'Coffee Machine', 210.00, '2026-09-22', 0, 'normal'),

-- 11. Old + final sale
(11, 'Gaming Chair', 320.00, '2026-06-15', 1, 'normal'),

-- 12. Incorrect item
(12, 'Tablet', 300.00, '2026-09-25', 0, 'incorrect'),

-- 13. Above $500
(13, 'Professional Camera', 1200.00, '2026-09-26', 0, 'normal'),

-- 14. Normal refundable order
(14, 'Backpack', 65.00, '2026-09-24', 0, 'normal'),

-- 15. Damaged item
(15, 'Office Monitor', 450.00, '2026-09-26', 0, 'damaged');