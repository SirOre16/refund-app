<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style type="text/css" media="all">
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: Arial, sans-serif;
    }
    .message-header-div {
      padding: 10px;
      height: 70px;
      border-bottom: 1px solid #bcc0c4;
    }
    .message-header {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .profile-pic-div {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .message-header-div-right-to-left .profile-pic-div {
      margin: 0;
      margin-left: 10px;
    }
    .profile-pic {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      object-fit: cover;
    }
    .message-user-info {
      display: flex;
      overflow: hidden;
      flex: 1;
    }
    #profile_name {
      font-weight: bold;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      display: inline-block;
      max-width: 100%;
      vertical-align: middle;
    }
    #profile_name a {
      color: #000;
      text-decoration: none;
    }
    .verified {
      margin-left: 2px;
      color: #fe2c55;
    }
    .message-header-div-right-to-left .verified {
      margin: 0;
      margin-right: 2px;
    }
    #message-header-three-dot {
      font-size: 30px;
      color: #999;
      margin-top: -10px;
      margin-right: 10px;
      margin-left: 10px;
      cursor: pointer;
    }
    #message-header-three-dot:hover {
      color: #fe2c55;
    }
    .message-header-menu-alert {
      margin-top: 10px;
      background: #ffffff;
      border-radius: 3%;
      display: none;
      position: absolute;
      right: 10px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      padding: 10px;
      z-index: 999;
      min-width: 180px;
      max-width: 300px;
    }
    .message-header-div-right-to-left .message-header-menu-alert {
      right: auto;
      left: 10px;
    }

    .message-header-triangle {
      width: 0;
      height: 0;
      border-left: 10px solid transparent;
      border-right: 10px solid transparent;
      border-bottom: 10px solid #f5f6f7;
      position: absolute;
      top: -10px;
      right: 10px;
    }

    .message-header-div-right-to-left .message-header-triangle {
      right: auto;
      left: 10px;
    }

    .message-header-menu-alert-content {
      margin-bottom: 8px;
      font-size: 16px;
      color: #333;
      padding: 10px;
      border-radius: 8px;
      max-width: 260px;
    }

    .message-header-menu-alert-content p {
      margin: 8px 0;
      cursor: pointer;
    }

    .message-header-menu-alert-content hr {
      border: none;
      border-top: 1px solid #eee;
      margin: 6px 0;
    }

    .message-header-menu-alert-content i {
      margin-right: 10px;
      font-size: 18px;
      vertical-align: middle;
      color: #555;
    }

    .message-header-div-right-to-left .message-header-menu-alert-content i {
      margin: 0;
      margin-left: 10px;
    }
    
    .body-dark-mode {
      background-color: #242526;
      color: #fff;
    }
    .message-header-div-dark-mode {
      border-bottom: 1px solid #444;
    }
    .message-header-div-dark-mode #profile_name a {
      color: #fff;
    }
    .message-header-div-dark-mode #message-header-three-dot {
      color: #888;
    }
    .message-header-div-dark-mode #message-header-three-dot:hover {
      color: #fe2c55;
    }
    .message-header-div-dark-mode .message-header-menu-alert {
      background: #2e2e2e;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
    }
    .message-header-div-dark-mode .message-header-triangle {
      border-bottom: 10px solid #2e2e2e;
    }
    .message-header-div-dark-mode .message-header-menu-alert-content {
      color: #e0e0e0;
      background: #2e2e2e;
    }
    .message-header-div-dark-mode .message-header-menu-alert-content hr {
      border-top: 1px solid #555;
    }
    .message-header-div-dark-mode .message-header-menu-alert-content i {
      color: #aaa;
    }
    .message-header-div-dark-mode #delete-message, .message-header-div-dark-mode #delete-message i {
      color: #e74c3c;
    }
  </style>
  <title>abdullah</title>
</head>
<body>
  <div class="message-header-div">
    <div class="message-header">
      <div class="profile-pic-div">
          <img src="modafvibe.png" class="profile-pic" alt="Profile picture">
      </div>
      <div class="message-user-info">
        <div id="profile_name">AI-Powered Customer Support Refund System</div>
        <div>
          <label class="verified"></label>
        </div>
      </div>
      <div class="message-header-menu-icon" onclick="showMessageHeaderMenuAlert(event);">
        <div id="message-header-three-dot">...</div>
        <div class="message-header-menu-alert">
          <div class="message-header-triangle"></div>
          <div class="message-header-menu-alert-content">
            <a href="admin.php" onclick="deleteAllMessages(event);"><i class="fas fa-user-cog"></i> Admin Dashboard</a>
            <hr />
            <a href="https://modafvibe.com/"><i class="fas fa-globe"></i> ModafVibe.com</a>
            <hr />
          </div>
        </div>
      </div>
    </div>
  </div>

<script>
  function showMessageHeaderMenuAlert(event) {
    var clickedMenuIcon = event.currentTarget;
    var menuAlert = clickedMenuIcon.querySelector('.message-header-menu-alert');

    // Display the menu alert
    menuAlert.style.display = "block";

    // Close any other open menu alerts
    document.querySelectorAll('.message-header-menu-alert').forEach(function(alert) {
      if (alert !== menuAlert) {
        alert.style.display = 'none';
      }
    });

    function closeMenuAlertOnClick(event) {
      if (!clickedMenuIcon.contains(event.target)) {
        menuAlert.style.display = "none";
        window.removeEventListener('click', closeMenuAlertOnClick);
      }
    }

    // Add event listener for window click to close the menu alert
    window.addEventListener('click', closeMenuAlertOnClick);
  }

  function deleteAllMessages(event) {
    // Add delete messages functionality here
  }

  
</script>

</body>
</html>