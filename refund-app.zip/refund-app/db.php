<?php 
$conn_host = "localhost";
$conn_username = "root";
$conn_password = "";
$conn_database = "refund_app";

// Establish the database connection
$conn = mysqli_connect($conn_host, $conn_username, $conn_password, $conn_database);

// Check if the connection was successful
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
